# Backend - Impregnation Department Shift Scheduler

## Setup Instructions

1. Create a virtual environment and activate it:
   python -m venv venv
   source venv/bin/activate  (Linux/Mac) or venv\Scripts\activate (Windows)

2. Install dependencies:
   pip install -r requirements.txt

3. Run the Flask app:
   python app.py
