from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///shift_schedule.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Operator(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    fixed_shift = db.Column(db.String(10), nullable=True)
    pair_id = db.Column(db.Integer, db.ForeignKey('operator.id'), nullable=True)

class Schedule(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    operator_id = db.Column(db.Integer, db.ForeignKey('operator.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    shift = db.Column(db.String(10), nullable=False)
    title = db.Column(db.String(200), nullable=True)

class Holiday(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    type = db.Column(db.String(20), nullable=False)

@app.route('/operators', methods=['GET', 'POST'])
def manage_operators():
    if request.method == 'POST':
        data = request.json
        operator = Operator(name=data['name'], fixed_shift=data.get('fixed_shift'), pair_id=data.get('pair_id'))
        db.session.add(operator)
        db.session.commit()
        return jsonify({'message': 'Operator added'}), 201
    else:
        operators = Operator.query.all()
        return jsonify([{'id': op.id, 'name': op.name, 'fixed_shift': op.fixed_shift, 'pair_id': op.pair_id} for op in operators])

@app.route('/schedule/generate', methods=['POST'])
def generate_schedule():
    data = request.json
    start_date = datetime.strptime(data['start_date'], '%Y-%m-%d')
    end_date = datetime.strptime(data['end_date'], '%Y-%m-%d')
    title = f"Impregnation dept Shift Schedule from {start_date.date()} to {end_date.date()}"

    operators = Operator.query.all()
    shifts = ['I', 'II', 'III']
    shift_index = 0

    for op in operators:
        current_date = start_date
        while current_date <= end_date:
            shift = op.fixed_shift if op.fixed_shift else shifts[shift_index % 3]
            schedule = Schedule(operator_id=op.id, date=current_date, shift=shift, title=title)
            db.session.add(schedule)
            current_date += timedelta(days=1)
        if not op.fixed_shift:
            shift_index += 1

    db.session.commit()
    return jsonify({'message': 'Schedule generated'}), 201

@app.route('/schedule/search', methods=['GET'])
def search_schedule():
    operator_id = request.args.get('operator_id')
    date = request.args.get('date')
    query = Schedule.query
    if operator_id:
        query = query.filter_by(operator_id=operator_id)
    if date:
        query = query.filter_by(date=datetime.strptime(date, '%Y-%m-%d'))
    results = query.all()
    return jsonify([{'operator_id': s.operator_id, 'date': s.date.isoformat(), 'shift': s.shift, 'title': s.title} for s in results])

@app.route('/monthly_offs/<int:operator_id>/<int:year>/<int:month>', methods=['GET'])
def monthly_offs(operator_id, year, month):
    offs = Schedule.query.filter_by(operator_id=operator_id, shift='OFF').filter(
        db.extract('year', Schedule.date) == year,
        db.extract('month', Schedule.date) == month
    ).all()
    return jsonify([s.date.isoformat() for s in offs])

@app.route('/holidays', methods=['POST'])
def add_holiday():
    data = request.json
    holiday = Holiday(date=datetime.strptime(data['date'], '%Y-%m-%d'), type=data['type'])
    db.session.add(holiday)
    db.session.commit()
    return jsonify({'message': 'Holiday added'}), 201

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
