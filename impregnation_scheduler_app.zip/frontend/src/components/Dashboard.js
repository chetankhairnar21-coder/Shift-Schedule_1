import React from 'react';
const Dashboard = () => <div>Dashboard Overview</div>;
export default Dashboard;
