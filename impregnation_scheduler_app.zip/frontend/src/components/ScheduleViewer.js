import React from 'react';
const ScheduleViewer = () => <div>Schedule Viewer</div>;
export default ScheduleViewer;
