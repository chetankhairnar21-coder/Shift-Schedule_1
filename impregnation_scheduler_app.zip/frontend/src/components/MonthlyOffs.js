import React from 'react';
const MonthlyOffs = () => <div>Monthly Offs</div>;
export default MonthlyOffs;
