import React from 'react';
const OperatorManagement = () => <div>Operator Management</div>;
export default OperatorManagement;
