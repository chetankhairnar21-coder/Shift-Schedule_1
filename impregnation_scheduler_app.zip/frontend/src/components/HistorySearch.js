import React from 'react';
const HistorySearch = () => <div>History Search</div>;
export default HistorySearch;
