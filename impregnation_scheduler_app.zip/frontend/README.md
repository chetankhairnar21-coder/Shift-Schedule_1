# Frontend - Impregnation Department Shift Scheduler

## Setup Instructions

1. Navigate to the frontend folder:
   cd frontend

2. Install dependencies:
   npm install

3. Start the React app:
   npm start
